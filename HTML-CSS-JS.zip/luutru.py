import json

def register_user(username, password):
    try:
        # Đọc dữ liệu từ tệp
        with open('user_data.json', 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        # Nếu tệp không tồn tại, tạo một từ điển mới
        data = {}

    # Kiểm tra xem tên người dùng đã tồn tại chưa
    if username in data:
        print(f"Người dùng '{username}' đã tồn tại.")
        return

    # Thêm thông tin người dùng mới
    data[username] = {'password': password}

    # Ghi dữ liệu vào tệp
    with open('user_data.json', 'w') as file:
        json.dump(data, file)

    print(f"Đăng ký người dùng '{username}' thành công.")

def get_user(username):
    try:
        # Đọc dữ liệu từ tệp
        with open('user_data.json', 'r') as file:
            data = json.load(file)
    except FileNotFoundError:
        # Nếu tệp không tồn tại, trả về None
        return None

    # Trả về thông tin người dùng nếu tồn tại
    return data.get(username)

# Ví dụ sử dụng
register_user('john_doe', 'secure_password')
user_data = get_user('john_doe')
print(f"Thông tin người dùng: {user_data}")